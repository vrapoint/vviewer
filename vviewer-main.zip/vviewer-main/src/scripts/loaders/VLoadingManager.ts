import * as THREE from 'VTHREE';

export default class VLoadingManager extends THREE.LoadingManager {
  constructor() {
    super();
  }
}

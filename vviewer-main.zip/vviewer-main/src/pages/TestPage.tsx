import FileTest from 'src/pages/FileTest.tsx';

function TestPage() {
  return (
    <div className="fullscreen">
      <FileTest />
    </div>
  );
}

export default TestPage;
